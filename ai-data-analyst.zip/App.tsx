/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */
import React, {useState, useCallback, useRef} from 'react';
import Papa from 'papaparse';
import {GeneratedContent} from './GeneratedContent';
import {streamAnalysis} from './services/geminiService';
import {ML_MODELS} from './constants';

const App: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [fileContent, setFileContent] = useState<string>('');
  const [analysisResult, setAnalysisResult] = useState<string>('');
  const [currentTask, setCurrentTask] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleReset = () => {
    setFile(null);
    setFileContent('');
    setAnalysisResult('');
    setCurrentTask('');
    setError(null);
    setIsLoading(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const runAnalysis = useCallback(async (task: string, content: string) => {
    if (!content) {
      setError('No file content to analyze.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setAnalysisResult('');
    setCurrentTask(task);

    try {
      const stream = streamAnalysis(task, content);
      for await (const chunk of stream) {
        setAnalysisResult((prev) => prev + chunk);
      }
    } catch (e: any) {
      setError(e.message || 'An unexpected error occurred during analysis.');
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile) {
      if (selectedFile.type !== 'text/csv') {
        setError('Please upload a valid CSV file.');
        return;
      }
      setFile(selectedFile);
      setError(null);

      const reader = new FileReader();
      reader.onload = async (e) => {
        const text = e.target?.result as string;
        setFileContent(text);
        // Automatically run EDA on file upload
        await runAnalysis(ML_MODELS[0], text);
      };
      reader.onerror = () => {
        setError('Failed to read the file.');
      };
      reader.readAsText(selectedFile);
    }
  };

  const handleTaskSelection = (task: string) => {
    if (fileContent) {
      runAnalysis(task, fileContent);
    } else {
      setError('Please upload a file first.');
    }
  };

  const renderFileUpload = () => (
    <div className="w-full max-w-lg text-center">
      <h1 className="text-4xl font-bold text-gray-800 mb-2">AI Data Analyst</h1>
      <p className="text-lg text-gray-600 mb-8">
        Upload your CSV file to get started with an automated analysis.
      </p>
      <div className="card">
        <label
          htmlFor="file-upload"
          className="relative cursor-pointer rounded-lg border-2 border-dashed border-gray-300 p-10 flex flex-col items-center justify-center hover:border-blue-500 transition-colors">
          <svg
            className="w-12 h-12 text-gray-400 mb-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M7 16a4 4 0 01-4-4V7a4 4 0 014-4h5l2 2h4a2 2 0 012 2v2a4 4 0 01-4 4H7z"></path>
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M9 16V6m0 0L7 8m2-2l2 2"></path>
          </svg>
          <span className="text-blue-600 font-semibold">
            Click to upload a file
          </span>
          <p className="text-sm text-gray-500 mt-1">CSV files only</p>
        </label>
        <input
          id="file-upload"
          ref={fileInputRef}
          type="file"
          accept=".csv"
          className="sr-only"
          onChange={handleFileChange}
        />
      </div>
      {error && (
        <p className="mt-4 text-red-600 bg-red-100 p-3 rounded-lg">
          {error}
        </p>
      )}
    </div>
  );

  const renderAnalysisView = () => (
    <div className="w-full h-full flex flex-col">
      <header className="flex-shrink-0 bg-white shadow-sm p-4 border-b flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-gray-800">
            Analysis Report
          </h1>
          <p className="text-sm text-gray-500">
            {file?.name} - {currentTask}
          </p>
        </div>
        <button
          onClick={handleReset}
          className="btn bg-gray-600 hover:bg-gray-700">
          Start Over
        </button>
      </header>

      <div className="flex-grow flex min-h-0">
        <aside className="w-64 bg-gray-50 p-4 border-r overflow-y-auto flex-shrink-0">
          <h2 className="text-lg font-semibold mb-4 text-gray-700">
            Analysis Tasks
          </h2>
          <div className="flex flex-col space-y-2">
            {ML_MODELS.map((task) => (
              <button
                key={task}
                onClick={() => handleTaskSelection(task)}
                disabled={isLoading}
                className={`w-full text-left p-2 rounded-md text-sm font-medium transition-colors ${
                  currentTask === task
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-600 hover:bg-gray-200'
                } disabled:opacity-50 disabled:cursor-not-allowed`}>
                {task}
              </button>
            ))}
          </div>
        </aside>

        <main className="flex-grow p-6 overflow-y-auto bg-gray-50/50">
          {isLoading ? (
            <div className="flex items-center justify-center h-full">
              <div className="text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500 mx-auto"></div>
                <p className="mt-4 text-gray-600">
                  Generating analysis, please wait...
                </p>
              </div>
            </div>
          ) : error ? (
            <div className="card bg-red-100 text-red-700">
              <h2 className="text-2xl font-bold">An Error Occurred</h2>
              <p>{error}</p>
            </div>
          ) : (
            <GeneratedContent htmlContent={analysisResult} />
          )}
        </main>
      </div>
    </div>
  );

  return (
    <div className="w-full min-h-screen flex items-center justify-center p-4 bg-gray-100">
      <div className="w-[95vw] h-[90vh] max-w-[1400px] bg-white rounded-xl shadow-2xl flex flex-col overflow-hidden">
        {!fileContent ? (
          <div className="w-full h-full flex items-center justify-center p-8">
            {renderFileUpload()}
          </div>
        ) : (
          renderAnalysisView()
        )}
      </div>
    </div>
  );
};

export default App;
